package kr.co.kurly.dto;

public class JungDto {
	private int id;
	private String code,title,deacode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDeacode() {
		return deacode;
	}
	public void setDeacode(String deacode) {
		this.deacode = deacode;
	}
	@Override
	public String toString() {
		return "JungDto [id=" + id + ", code=" + code + ", title=" + title + ", deacode=" + deacode + "]";
	}
	
	
	
}
