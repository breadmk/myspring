package kr.co.kurly.dto;

public class ProductDto {
    private int id,price,bgubun,gihan,su,halin;
    private String mimg,title,subtitle,pdan,pwe;
    private String made,pal,pcon,pimg,pinfo,writeday,pcode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getBgubun() {
		return bgubun;
	}
	public void setBgubun(int bgubun) {
		this.bgubun = bgubun;
	}
	public int getGihan() {
		return gihan;
	}
	public void setGihan(int gihan) {
		this.gihan = gihan;
	}
	public int getSu() {
		return su;
	}
	public void setSu(int su) {
		this.su = su;
	}
	public int getHalin() {
		return halin;
	}
	public void setHalin(int halin) {
		this.halin = halin;
	}
	public String getMimg() {
		return mimg;
	}
	public void setMimg(String mimg) {
		this.mimg = mimg;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSubtitle() {
		return subtitle;
	}
	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}
	public String getPdan() {
		return pdan;
	}
	public void setPdan(String pdan) {
		this.pdan = pdan;
	}
	public String getPwe() {
		return pwe;
	}
	public void setPwe(String pwe) {
		this.pwe = pwe;
	}
	public String getMade() {
		return made;
	}
	public void setMade(String made) {
		this.made = made;
	}
	public String getPal() {
		return pal;
	}
	public void setPal(String pal) {
		this.pal = pal;
	}
	public String getPcon() {
		return pcon;
	}
	public void setPcon(String pcon) {
		this.pcon = pcon;
	}
	public String getPimg() {
		return pimg;
	}
	public void setPimg(String pimg) {
		this.pimg = pimg;
	}
	public String getPinfo() {
		return pinfo;
	}
	public void setPinfo(String pinfo) {
		this.pinfo = pinfo;
	}
	public String getWriteday() {
		return writeday;
	}
	public void setWriteday(String writeday) {
		this.writeday = writeday;
	}
	public String getPcode() {
		return pcode;
	}
	public void setPcode(String pcode) {
		this.pcode = pcode;
	}
	@Override
	public String toString() {
		return "ProductDto [id=" + id + ", price=" + price + ", bgubun=" + bgubun + ", gihan=" + gihan + ", su=" + su
				+ ", halin=" + halin + ", mimg=" + mimg + ", title=" + title + ", subtitle=" + subtitle + ", pdan="
				+ pdan + ", pwe=" + pwe + ", made=" + made + ", pal=" + pal + ", pcon=" + pcon + ", pimg=" + pimg
				+ ", pinfo=" + pinfo + ", writeday=" + writeday + ", pcode=" + pcode + "]";
	}
    
    
    
}
